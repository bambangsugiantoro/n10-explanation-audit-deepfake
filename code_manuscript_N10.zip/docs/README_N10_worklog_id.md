# N10 — dokumentasi kerja (dibangun ulang 18 Nov 2026)

Judul kerja: *Do explanations reveal when deepfake detectors fail? A pre-specified audit of attribution agreement and counter-class evidence under generator shift*
Penulis: Bambang Sugiantoro (korespondensi), Faiz Akhmad Hafizuddin (sama dengan N20; Imam Solekhudin dihapus, disetujui 18 Nov).
Jurnal sasaran: Discover Artificial Intelligence (utama; kuartil Q1 dikonfirmasi pengguna lewat Scimago 18 Nov 2026, kategori belum dicatat; dari cek saya sendiri kategori AI/CS Applications tampak Q2 di mirror pihak ketiga, tidak terverifikasi), Multimedia Systems (cadangan). Gaya: STYLE_N10_DiscoverAI.md.
Sumber awal: naskah N10 ditolak The Visual Computer; tawaran transfer Springer aktif (BATAS WAKTU belum dicek: lihat halaman transfer; perkiraan ~Feb 2027).
Anti-tumpang tindih: tanpa conformal (N19), tanpa cascade/latensi (N20). N15 tetap diparkir.

## 1. Peta berkas (C:\deepfake\novelty\)
| Berkas | Isi |
|---|---|
| PLAN_N10_rebuild.md | keputusan, RQ1-3, H1-H4, desain, jurnal |
| HYPOTHESES_LOCK_N10.txt | hash SHA-256 bagian H1-H4 (b7ecfb94...0f57), dikunci 18 Nov 2026 sebelum eksperimen |
| xai_audit.py | skrip audit (Grad-CAM, IG, SmoothGrad; kelas terpilih & tak terpilih) |
| 20_xai.sbatch | job Slurm audit (1 GPU) |
| N10_manuscript_draft.tex/.pdf | kerangka naskah (hasil masih kosong) |
| STYLE_N10_DiscoverAI.md | aturan jurnal + pola artikel terbit |
| README_N10.md | berkas ini |
Kode N10 lama (dibaca, tidak diubah): C:\deepfake\agca\code\ (agcp.py, make_per_image_csv.py, cf_agreement.py, train_arch.py) dan C:\deepfake\untuk_claude\.

## 2. Lokasi di HPC (/virtiofs/work/bambang/cascade = $R)
- Data: $R/data/proc/face/{orig,rs,jpg,c}/<shard>.tar; manifest: $R/data/proc/face/manifest/*.csv
- Model: $R/models/{resnet50_face,mnv3_l_face,resnet50_ft,mnv3_l_ft}.pt (lama); baru: convnext_t_face.pt, vit_b_face.pt (setelah job 1958/1959)
- Skrip: $R/scripts/{finetune_tier.py, xai_audit.py, 20_xai.sbatch, 21_ft_n10.sbatch}
- Keluaran audit: $R/xai/<model>_<cond>.csv (+ .part saat berjalan); log: $R/logs/
- Container: apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python ...

## 3. Job yang diajukan 18 Nov 2026
| ID | Nama | Isi | Ketergantungan |
|---|---|---|---|
| 1958 | ft_cnx | latih ConvNeXt-T (convnext_tiny -> convnext_t_face) | - |
| 1959 | ft_vit | latih ViT-B/16 (vit_base_patch16_224 -> vit_b_face) | - |
| 1960 | xai_r50 | audit resnet50_face | - |
| 1962 | xai_cnx | audit convnext_t_face | afterok:1958 |
| 1963 | xai_vit | audit vit_b_face | afterok:1959 |
Saat diajukan GPU dipegang job 1957 (pengguna lain) sampai paling lambat 20 Nov 14:56.

## 4. Menjalankan ulang / memperluas
- Audit satu detektor: `cd $R/scripts; sbatch -J xai_<x> 20_xai.sbatch <nama_timm> <nama_model>` (nama_timm mis. resnet50, convnext_tiny, vit_base_patch16_224; bobot dibaca $R/models/<nama_model>.pt).
- Kondisi lain (kompresi): `COND=jpg sbatch ...` (default orig). Sampel/seed: NPER, NREAL, SEED, IGSTEPS, SGN lewat env.
- Melanjutkan job putus: jalankan lagi; baris yang sudah ada di CSV dilewati (resume per key).
- Detektor baru: latih dengan `DS=face EPOCHS=6 NW=14 python finetune_tier.py <timm> <nama>` (via 21_ft_n10.sbatch), lalu audit. Arsitektur baru perlu entri di target_layer() pada xai_audit.py.
- Penjelas baru: tambahkan fungsi seperti smoothgrad() lalu masukkan ke agreement()/explain().
- Sampel dikunci seed 20261118 dan manifest, tidak memakai keluaran model.

## 5. Kolom CSV keluaran
key, generator, family, role, label, p_fake, pred, wrong, msp, margin, agree_pred, agree_gc_ig, agree_ig_sg, agree_other, mass_pred, mass_other.
Analisis: AUROC(wrong) untuk msp (1-msp), agree_pred, agree_other, mass_other/mass_pred; bootstrap 2.000x; stratifikasi label; alarm shift = AUROC sumber vs target.

## 6. Playbook revisi
- "Tambah detektor/generator": bagian 4, lalu jalankan ulang analisis; hipotesis H1-H4 TIDAK diubah (hash terkunci); tambahan dilaporkan sebagai eksplorasi.
- "Tambah penjelas (mis. attention rollout, LIME)": bagian 4.
- "Bukti faithfulness (deletion/insertion)": belum dikerjakan; tambahkan skrip terpisah memakai model + peta yang sama.
- "Kompresi": COND=jpg.
- Unggah data/kode: repo GitHub + Zenodo seperti N20 (bambangsugiantoro/n20-certified-deepfake-cascade sebagai contoh); isi Data availability.
- Ubah daftar penulis di sistem Springer saat transfer (dua penulis).

## 7. Hasil awal (18 Nov 2026, dibaca dari terminal; BELUM final, ViT-B belum selesai)
Sampel audit: 79.130 gambar, 56 generator (75.130 palsu, 4.000 asli), kondisi orig. 37 dari 56 generator punya cukup kesalahan (>=20 per kelas) untuk AUROC per generator.
Berkas hasil di HPC: $R/xai/an_<model>.txt (ringkasan), $R/xai/an_<model>_results.csv (tabel lengkap: level pooled/family/generator/shift; kolom auc, lo, hi, diff_vs_msp, dlo, dhi, n).
- Galat sumber 0,4%, galat target 49% (ResNet-50): pergeseran generator sangat kuat.
- H1 (agreement ~0,5): GAGAL pada ConvNeXt-T (hanya 13,5% generator CI memuat 0,5); agreement AUROC gabungan 0,66 (ConvNeXt-T), 0,77 pada generator palsu (ResNet-50).
- H2 (counter-class > MSP): GAGAL; "other" AUROC ~0,27 (di bawah 0,5 pada orientasi yang dikunci); kalah dari MSP di 76% generator (ConvNeXt-T); "ratio" kalah di semua.
- H4 (alarm shift): GAGAL; counter-class menang atas MSP dan agreement di 0% (ConvNeXt-T) dan 2,6% (ResNet-50) generator. MSP alarm shift kuat (AUROC median 0,81 ResNet-50; 0,93 ConvNeXt-T).
- MSP pada ConvNeXt-T AUROC 0,42 (<0,5): kesalahan cenderung lebih yakin.
- Margin logit identik dengan MSP (dua kelas): dibuang dari analisis.
- Arah sinyal berbalik antara asli dan palsu (ResNet-50): sinyal terikat kelas prediksi. Pembalikan arah = eksploratif; JANGAN diklaim sebagai konfirmasi H2. Perlu analisis stratifikasi kelas prediksi (eksploratif).

## 7b. ViT-B (18 Nov 2026, 79.130 gambar, 38 generator dianalisis) dan KOREKSI ANALISIS
ViT-B: H1 agreement CI memuat 0,5 di 0% generator; agreement vs MSP: lebih baik 42%, lebih buruk 42%; "other" kalah dari MSP (66%); "ratio" AUROC gabungan 0,936 dan mengalahkan MSP di 100% generator; H4: ratio menang di 37% generator; MSP shift AUROC median 0,88.
PERINGATAN VALIDITAS (ditemukan saat meninjau hasil): analisis per-generator memakai gambar PALSU saja, dan di sana "salah" sama dengan "diprediksi asli". Maka AUROC tiap sinyal di dalam stratum label sebagian besar mengukur apakah sinyal membedakan KELAS YANG DIPREDIKSI, bukan apakah keputusan salah. Ini menjelaskan tanda yang berbalik antara stratum asli dan palsu dan nilai ekstrem (ratio 0,936). Karena itu temuan "agreement informatif" (H1 gagal) dan "ratio unggul" TIDAK boleh dianggap valid sebelum analisis terkondisi diulang.
Analisis yang benar (menggantikan analisis pertama, yang tetap dilaporkan sebagai analisis yang dikoreksi): AUROC kesalahan DI DALAM tiap kelas yang diprediksi (dirilis sebagai palsu: kesalahan = gambar asli; dirilis sebagai asli: kesalahan = gambar palsu), dengan generator sebagai sumber kesalahan, plus kontrol terhadap kelas prediksi (stratifikasi/regresi). H1-H4 tetap sama; H1 menyebut "keputusan yang dirilis" sehingga analisis terkondisi adalah pembacaan yang benar atas hipotesis terkunci.
Berkas: $R/xai/an_vit_b_face.txt, an_vit_b_face_results.csv.

## 7c. Analisis TERKONDISI kelas prediksi (18 Nov 2026 pukul ~16:25 WIB) — menggantikan 7 dan 7b
Skrip: scripts/analyze_cond.py (salinan: C:\deepfake\novelty\analyze_cond.py; B=1000 bootstrap). Keluaran HPC: $R/xai/cond_<model>.txt dan an_<model>_cond.csv.
Definisi: di antara keputusan yang dirilis sebagai "asli" (kesalahan = palsu target yang lolos) dan yang dirilis sebagai "palsu" (kesalahan = gambar asli yang dituduh palsu), AUROC kesalahan tiap sinyal (arah terkunci: agreement rendah, bukti kelas lawan tinggi, MSP rendah = mencurigakan).
Hasil gabungan target (kesalahan: released_real / released_fake):
- ConvNeXt-T: released_real: MSP 0,539; agreement 0,694 [0,684-0,704] (lebih baik dari MSP +0,155); other 0,496; ratio 0,527. released_fake (636 kesalahan): MSP 0,618; agreement 0,613 (selisih -0,004, tidak berbeda); other 0,609 (n.s.); ratio 0,505 (lebih buruk -0,113).
- ResNet-50: released_fake (703 kesalahan): MSP 0,631; agreement 0,573 (-0,057); other 0,547 (-0,083); ratio 0,454 (-0,176). released_real: BELUM dicatat (baca xai/cond_resnet50_face.txt).
- ViT-B: hampir seluruhnya mendekati 0,5. released_real: MSP 0,517; agreement 0,513; other 0,490; ratio 0,536 (+0,019 vs MSP, CI +0,006..+0,032). released_fake: MSP 0,560; agreement 0,473 (-0,087); other 0,532; ratio 0,590 (+0,030, CI +0,012..+0,046).
Per generator (ViT-B, 38 generator): agreement CI>0,5 di 26% (released_real) dan 42% (released_fake); counter-class "other" CI>0,5 di 58%/53%; ratio 74%/66%; MSP 50%/61%.
Pembacaan sementara (hati-hati; belum final): setelah dikondisikan, tidak ada sinyal yang kuat. Agreement berguna hanya pada satu sel (ConvNeXt-T, dirilis asli); H1 benar untuk ViT-B dan sebagian ConvNeXt-T, jadi heterogen antardetektor. Counter-class (H2) tidak mengalahkan MSP secara umum; rasio hanya sedikit lebih baik pada ViT-B (+0,02..+0,03) dan lebih buruk pada detektor lain. H4 (alarm shift) tidak didukung (MSP kuat). Ini cocok disajikan sebagai audit hasil negatif/heterogen.
Belum dikerjakan: kontrol prevalensi, uji permutasi, koreksi perbandingan berganda, kondisi JPEG, deletion/insertion.

## 7d. Kontrol tambahan (18 Nov 2026 ~17:20 WIB) — skrip scripts/analyze_extra.py; hasil $R/xai/an_<model>_extra.csv, extra_<model>.txt
Isi: (a) uji permutasi pooled (1000), (b) AUROC dicocokkan pada desil MSP (menguji informasi di luar keyakinan), (c) per-generator dengan z-test bootstrap-SE (B=300) dan koreksi Holm. Semua eksploratif kecuali dinyatakan lain.
(a) Permutasi: hampir semua p<0,001 (n sangat besar; signifikansi statistik tidak sama dengan efek berguna). Pengecualian: ConvNeXt-T released_fake ratio p=0,69; ViT-B released_real other p=0,078, agreement p=0,026.
(b) Dicocokkan MSP, ViT-B: released_real MSP 0,476, agreement 0,523, other 0,480, ratio 0,536; released_fake MSP 0,518, agreement 0,481, other 0,523, ratio 0,567. ConvNeXt-T released_fake: MSP 0,511, agreement 0,547, other 0,557, ratio 0,532. Efek kecil (<=0,07 dari 0,5).
(c) Jumlah generator signifikan setelah Holm (naik = AUROC>0,5; turun = <0,5): hasil tersebar di KEDUA arah untuk hampir semua sinyal, mis. ConvNeXt-T released_real agreement naik 26/turun 6 (median 0,713), MSP naik 23/turun 14 (median 0,787); ViT-B released_fake agreement naik 9/turun 21 (median 0,411), ratio naik 27/turun 1 (median 0,587); ResNet-50 released_real ratio naik 4/turun 29 (median 0,322).
Pembacaan: efek gabungan kecil, efek per-generator besar dan tanda berubah antargenerator dan antardetektor. Klaim harus per detektor dan per kelas rilis; tidak ada sinyal yang konsisten unggul. Peringatan: AUROC per generator memakai gambar asli yang dirilis benar sebagai pembanding (hanya 4.000 asli), sehingga komposisi pembanding mempengaruhi angka; laporkan sebagai keterbatasan.
Catatan: angka ResNet-50 released_real pada analisis terkondisi (cond) belum dicatat satu per satu; baca xai/cond_resnet50_face.txt.

## 8. Status & log
- 18 Nov 2026: rencana, hash, skrip diuji CPU, kerangka naskah, penulis (2), judul, checklist mutu, panduan panjang naskah. HPC: latih ConvNeXt-T (job 1958) dan ViT-B (1959) selesai; audit ResNet-50 (1960) dan ConvNeXt-T (1962) selesai (79.130 baris); audit ViT-B (1963) berjalan (57.600 baris pukul 14:37 WIB, ~6 baris/detik, selesai ~15:40).
- Catatan operasional: terminal OnDemand putus saat menganggur; job Slurm tetap jalan. Akses browser ke HPC meminta persetujuan per aksi (pilih "Always allow for this website"). Pelatihan jauh lebih cepat dari perkiraan (~95-145 detik/epoch); audit ~13 baris/detik ResNet/ConvNeXt, ~6 ViT.
- TODO berikutnya: (0) ulang analisis TERKONDISI pada kelas prediksi (lihat 7b), (1) analisis ViT-B: `apptainer exec $R/env/pytorch.sif $R/env/venv/bin/python scripts/analyze_xai.py xai/vit_b_face_orig.csv xai/an_vit_b_face > xai/an_vit_b_face.txt`; (2) tambah stratifikasi kelas prediksi (eksploratif), buang margin; (3) tarik hasil ke komputer dan buat tabel/gambar; (4) tulis Results/Discussion; (5) verifikasi referensi; (6) rilis repo + Zenodo; (7) templat Springer, cover letter, cek batas transfer; (8) sinkron dashboard N10 (alat dashboard tidak tersedia di sesi ini; lakukan di sesi berikut).
- Opsional bila diminta reviewer: detektor CLIP ViT-L/14 + probe; kondisi JPEG (COND=jpg); deletion/insertion faithfulness; penjelas lain.
