# Verifikasi referensi N10 (18 Nov 2026)
Metode: tiap entri dicek ke halaman resmi/repositori (proceedings NeurIPS/CVF/PMLR, arXiv, mlanthology, bibbase, Zenodo, PubMed). Hanya yang terverifikasi dipakai. Status:
- OK = judul, penulis, venue, tahun, halaman/DOI cocok dengan sumber yang dibuka sesi ini.
- SEBAGIAN = ada kolom yang belum terkonfirmasi (lihat catatan).

| Kunci | Status | Catatan |
|---|---|---|
| gradcam | OK | IJCV 128(2):336-359 (bibbase); DOI 10.1007/s11263-019-01228-7 (datalearner) |
| ig | OK | ICML 2017, hlm 3319-3328, PMLR v70 |
| sg | OK | arXiv:1706.03825; penulis dicek pada halaman pertama |
| adebayo2018 | OK | NIPS 2018 (prosiding vol 31); halaman tidak dicantumkan |
| df40 | OK | NeurIPS 2024 D&B, vol 37, hlm 29387-29434 |
| diff | OK | hanya arXiv:2401.15859 (tidak ada venue pada halaman arXiv); jangan tulis venue |
| hendrycks2017 | OK | ICLR 2017 |
| he2016 | OK | CVPR 2016 hlm 770-778 |
| liu2022 | OK | CVPR 2022 hlm 11976-11986 |
| dosovitskiy2021 | OK | ICLR 2021 |
| timm | SEBAGIAN | DOI konsep 10.5281/zenodo.4414861 (semua versi); versi terpasang di HPC belum dicatat |
| adamw | OK | ICLR 2019 |
| onecycle | SEBAGIAN | arXiv:1708.07120 terverifikasi ada; versi SPIE (Proc SPIE 11006) tidak dibuka |
| hanley1982 | SEBAGIAN | PMID 7063747 muncul pada hasil pencarian; halaman PubMed gagal dibuka; 143(1):29-36 dari sitasi baku |
| holm1979 | OK | Scand J Stat 6(2):65-70 |
| rossler2019 | OK | ICCV 2019, DOI 10.1109/ICCV.2019.00009; halaman tidak dicantumkan |
| ojha2023 | OK | CVPR 2023; halaman tidak dicantumkan |
| hooker2019 | OK | NeurIPS 2019 hlm 9737-9748 |
| kindermans2019 | OK | arXiv:1711.00867 (versi Springer tidak dicek, tidak dipakai) |
| krishna2024 | OK | TMLR 2024; daftar penulis diperbaiki (draf awal salah) |
| geifman2017 | OK | NeurIPS 2017 hlm 4878-4887 |
| guo2017 | OK | ICML 2017 v70 hlm 1321-1330 |
| ovadia2019 | OK | NeurIPS 2019 hlm 13991-14002 |
| wang2020 | OK | CVPR 2020 hlm 8695-8704 |
| ribeiro2016 | SEBAGIAN | dikutip sebagai arXiv:1602.04938; versi KDD tidak dikonfirmasi |
| lundberg2017 | OK | NIPS 2017 (vol 30) |
| rudin2019 | OK | NMI 1(5):206-215, DOI 10.1038/s42256-019-0048-x |
| geirhos2020 | OK | NMI 2(11):665-673, DOI 10.1038/s42256-020-00257-z |
| lakshminarayanan2017 | OK | NeurIPS 2017 hlm 6402-6413 |
| rabanser2019 | OK | NeurIPS 2019 hlm 1396-1408 |
| verdoliva2020 | SEBAGIAN | JSTSP 14(5) 2020; halaman dan DOI belum terkonfirmasi (sengaja dihilangkan) |
| yan2023 | OK | NeurIPS 2023 D&B (DeepfakeBench) |
| doshivelez2017 | OK | arXiv:1702.08608 |
| ghorbani2019 | OK | AAAI 2019 hlm 3681-3688, DOI 10.1609/aaai.v33i01.33013681 |
| dolhansky2020 | OK | arXiv:2006.07397 |
| corvi2023 | OK | arXiv:2211.00680 (venue tidak tertera pada arXiv; tidak ditulis) |
| simonyan2014 | OK | arXiv:1312.6034 |
| zhou2016 | OK | CVPR 2016 hlm 2921-2929 |
| delong1988 | OK | Biometrics 44(3):837-845 (nomor terbitan dari sitasi baku) |
| efron1993 | SEBAGIAN | buku baku; tidak dibuka sumbernya sesi ini |

Sebelum submit: lengkapi kolom SEBAGIAN (halaman/DOI), catat versi timm dari HPC, ganti arXiv dengan versi terbit bila ada.
Koreksi dari draf awal: daftar penulis Krishna et al. (salah), halaman FF++ dan Kindermans (tidak terkonfirmasi, dihapus).
