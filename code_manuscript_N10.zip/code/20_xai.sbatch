#!/bin/bash
#SBATCH -p l40s
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=48G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/xai_%x_%j.out
# Versi yang dipakai di HPC (18 Nov 2026). usage: sbatch -J xai_<x> 20_xai.sbatch <timm_name> <model_name>
export R=/virtiofs/work/bambang/cascade DS=face COND=${COND:-orig}
cd $R/scripts
apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python xai_audit.py "$1" "$2"
