import pandas as pd, numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
H="/home/claude/n10/hasil/"; M=[("resnet50","ResNet-50"),("convnext_t","ConvNeXt-T"),("vit_b","ViT-B/16")]
SIG=[("msp","MSP"),("agree","Agreement"),("other","Counter-class"),("ratio","Mass ratio")]
COL={"msp":"#000000","agree":"#0072B2","other":"#D55E00","ratio":"#009E73"}
UN=[("released_real","Released as real (errors = missed fakes)"),("released_fake","Released as fake (errors = reals flagged)")]
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42})
C={m:pd.read_csv(f"{H}an_{m}_face_cond.csv") for m,_ in M}; X={m:pd.read_csv(f"{H}an_{m}_face_extra.csv") for m,_ in M}
# Fig1 pooled forest
fig,ax=plt.subplots(1,2,figsize=(7.2,3.4),sharey=True)
for j,(u,ut) in enumerate(UN):
    a=ax[j]; y=0; ticks=[];lab=[]
    for m,mn in M:
        d=C[m]; p=d[(d.level=="pooled")&(d.unit==u)].set_index("signal")
        for k,(s,sn) in enumerate(SIG):
            r=p.loc[s]; a.errorbar(r.auc,y,xerr=[[r.auc-r.lo],[r.hi-r.auc]],fmt="o",ms=4,color=COL[s],capsize=2,lw=1.2,label=sn if (m=="resnet50") else None)
            y-=1
        ticks.append(y+2.5); lab.append(mn); y-=0.8
    a.axvline(0.5,color="grey",ls="--",lw=.8); a.set_yticks(ticks); a.set_yticklabels(lab); a.set_xlim(0.38,0.74)
    a.set_xlabel("Pooled AUROC (95% bootstrap CI)"); a.set_title(["(a) Released as real","(b) Released as fake"][j],fontsize=9,loc="left")
ax[0].legend(frameon=False,fontsize=8,loc="lower right")
fig.tight_layout(); fig.savefig("/home/claude/n10/fig/fig_pooled.pdf"); fig.savefig("/home/claude/n10/fig/fig_pooled.png",dpi=300)
# Fig2 per-generator distributions
fig,ax=plt.subplots(2,3,figsize=(7.2,5.2),sharey=True)
for i,(u,_) in enumerate(UN):
    for j,(m,mn) in enumerate(M):
        a=ax[i,j]; d=C[m]; g=d[(d.level=="generator")&(d.unit.str.startswith(u+":"))]
        rng=np.random.RandomState(1)
        for k,(s,sn) in enumerate(SIG):
            v=g[g.signal==s].auc.values
            a.scatter(k+rng.uniform(-.17,.17,len(v)),v,s=7,color=COL[s],alpha=.7,lw=0)
            a.hlines(np.median(v),k-.3,k+.3,color="k",lw=1.4)
        a.axhline(.5,color="grey",ls="--",lw=.8); a.set_xticks(range(4)); a.set_xticklabels(["MSP","Agr.","Ctr.","Ratio"],fontsize=7.5)
        if i==0: a.set_title(mn,fontsize=9)
        if j==0: a.set_ylabel(["Released as real\nper-generator AUROC","Released as fake\nper-generator AUROC"][i])
        a.set_ylim(0.1,1.0)
fig.tight_layout(); fig.savefig("/home/claude/n10/fig/fig_pergen.pdf"); fig.savefig("/home/claude/n10/fig/fig_pergen.png",dpi=300)
# Table pooled
def f(x): return f"{x:.3f}"
L=[r"\begin{tabular}{llrrcccc}",r"\toprule",r"Detector & Released as & $n$ & Errors & MSP & Agreement & Counter-class & Mass ratio\\",r"\midrule"]
for m,mn in M:
    for u,un in [("released_real","real"),("released_fake","fake")]:
        p=C[m][(C[m].level=="pooled")&(C[m].unit==u)].set_index("signal")
        cells=[f"{f(p.loc[s].auc)} [{f(p.loc[s].lo)}, {f(p.loc[s].hi)}]" for s,_ in SIG]
        L.append(f"{mn} & {un} & {int(p.loc['msp'].n):,} & {int(p.loc['msp'].nerr):,} & "+" & ".join(cells)+r"\\")
    if m!="vit_b": L.append(r"\midrule")
L+= [r"\bottomrule",r"\end{tabular}"]; open("/home/claude/n10/tab/tab_pooled.tex","w").write("\n".join(L).replace("&","&",1))
# Table per-generator Holm
L=[r"\begin{tabular}{llcccc}",r"\toprule",r"Detector & Released as & Signal & Generators & Sig.\ $>0.5$ & Sig.\ $<0.5$\\",r"\midrule"]
for m,mn in M:
    x=X[m]; h=x[x.test=="gen_holm"]
    for u,un in [("released_real","real"),("released_fake","fake")]:
        for s,sn in SIG:
            r=h[(h.cls==u)&(h.signal==s)].iloc[0]
            L.append(f"{mn} & {un} & {sn} & {int(r.n)} & {int(r.n_sig_up)} & {int(r.n_sig_down)}\\\\")
    if m!="vit_b": L.append(r"\midrule")
L+=[r"\bottomrule",r"\end{tabular}"]; open("/home/claude/n10/tab/tab_holm.tex","w").write("\n".join(L))
# Table controls
L=[r"\begin{tabular}{llcccc}",r"\toprule",r"Detector & Released as & Signal & Pooled AUROC & Permutation $p$ & MSP-matched AUROC\\",r"\midrule"]
for m,mn in M:
    x=X[m]
    for u,un in [("released_real","real"),("released_fake","fake")]:
        for s,sn in SIG:
            a=x[(x.test=="perm_pooled")&(x.cls==u)&(x.signal==s)].iloc[0]; b=x[(x.test=="msp_matched")&(x.cls==u)&(x.signal==s)].iloc[0]
            p="<0.001" if a.p<0.001 else f"{a.p:.3f}"
            L.append(f"{mn} & {un} & {sn} & {f(a.auc)} & {p} & {f(b.auc)}\\\\")
    if m!="vit_b": L.append(r"\midrule")
L+=[r"\bottomrule",r"\end{tabular}"]; open("/home/claude/n10/tab/tab_controls.tex","w").write("\n".join(L))
print("ok")
