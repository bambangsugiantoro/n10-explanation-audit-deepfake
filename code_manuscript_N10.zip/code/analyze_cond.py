import sys, os, numpy as np, pandas as pd
from scipy.stats import rankdata
B = int(os.environ.get("B", 1000)); RNG = np.random.RandomState(20261118)
NAMES = ["msp", "agree", "other", "ratio"]
def auc(y, s):
    n1 = y.sum(); n0 = len(y) - n1
    if n1 < 20 or n0 < 20: return np.nan
    r = rankdata(s); return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def sc(d): return {"msp": (-d.msp).values, "agree": (-d.agree_pred).values, "other": d.agree_other.values, "ratio": (d.mass_other / d.mass_pred).values}
def boot(y, S):
    n = len(y); est = {k: auc(y, S[k]) for k in NAMES}
    if np.isnan(est["msp"]): return None
    bs = {k: [] for k in NAMES}
    for _ in range(B):
        i = RNG.randint(0, n, n); yy = y[i]
        if yy.sum() < 5 or (1 - yy).sum() < 5: continue
        for k in NAMES: bs[k].append(auc(yy, S[k][i]))
    bs = {k: np.array(v) for k, v in bs.items()}; out = {}
    for k in NAMES:
        lo, hi = np.nanpercentile(bs[k], [2.5, 97.5])
        if k == "msp": dd = (np.nan, np.nan, np.nan)
        else: dd = (est[k] - est["msp"], *np.nanpercentile(bs[k] - bs["msp"], [2.5, 97.5]))
        out[k] = (est[k], lo, hi) + dd
    return out
def main(csv, pre):
    d = pd.read_csv(csv); rows = []
    reals = d[d.label == 0]
    for cls, name in [(0, "released_real"), (1, "released_fake")]:
        rel = d[d.pred == cls]
        # pooled over target generators
        if cls == 0: sub = pd.concat([rel[(rel.label == 1) & (rel.role == "target")], rel[rel.label == 0]])
        else: sub = pd.concat([rel[(rel.label == 1) & (rel.role == "target")], rel[rel.label == 0]])
        o = boot(sub.wrong.values, sc(sub))
        if o:
            for k in NAMES: rows.append(dict(level="pooled", unit=name, signal=k, auc=o[k][0], lo=o[k][1], hi=o[k][2], d_msp=o[k][3], dlo=o[k][4], dhi=o[k][5], n=len(sub), nerr=int(sub.wrong.sum())))
        # per generator: errors vs reference of correct decisions in the released class
        if cls == 0:   # errors = missed fakes of g; reference = correctly released reals
            ref = rel[(rel.label == 0)]
            for g, f in rel[(rel.label == 1) & (rel.role == "target")].groupby("generator"):
                z = pd.concat([f, ref]); o = boot(z.wrong.values, sc(z))
                if o:
                    for k in NAMES: rows.append(dict(level="generator", unit=name + ":" + g, signal=k, auc=o[k][0], lo=o[k][1], hi=o[k][2], d_msp=o[k][3], dlo=o[k][4], dhi=o[k][5], n=len(z), nerr=int(z.wrong.sum())))
        else:          # errors = reals released as fake; reference = correct fakes of g
            err = rel[rel.label == 0]
            for g, f in rel[(rel.label == 1) & (rel.role == "target")].groupby("generator"):
                z = pd.concat([f, err]); o = boot(z.wrong.values, sc(z))
                if o:
                    for k in NAMES: rows.append(dict(level="generator", unit=name + ":" + g, signal=k, auc=o[k][0], lo=o[k][1], hi=o[k][2], d_msp=o[k][3], dlo=o[k][4], dhi=o[k][5], n=len(z), nerr=int(z.wrong.sum())))
    r = pd.DataFrame(rows); r.to_csv(pre + "_cond.csv", index=False)
    print("POOLED (conditioned on released class)")
    print(r[r.level == "pooled"][["unit", "signal", "auc", "lo", "hi", "d_msp", "dlo", "dhi", "n", "nerr"]].round(3).to_string())
    g = r[r.level == "generator"].copy(); g["cls"] = g.unit.str.split(":").str[0]
    for c, x in g.groupby("cls"):
        for k in ["agree", "other", "ratio"]:
            y = x[x.signal == k]; print(f"{c} {k}: n_gen {len(y)}; auc CI>0.5 {(y.lo>.5).mean():.2f}; auc CI<0.5 {(y.hi<.5).mean():.2f}; vs msp better {(y.dlo>0).mean():.2f} worse {(y.dhi<0).mean():.2f}")
        y = x[x.signal == "msp"]; print(f"{c} msp: auc CI>0.5 {(y.lo>.5).mean():.2f}; CI<0.5 {(y.hi<.5).mean():.2f}")
if __name__ == "__main__": main(sys.argv[1], sys.argv[2])
