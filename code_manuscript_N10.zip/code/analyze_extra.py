"""N10 extra controls (exploratory unless stated). usage: python analyze_extra.py <csv> <prefix>
(a) pooled permutation p-values (1000 perms) for AUROC vs 0.5, per released class and signal
(b) confidence-matched AUROC: AUROC of each signal within MSP deciles, size-weighted (does the signal add information beyond MSP?)
(c) per-generator AUROC with bootstrap-SE z-test (B=300), Holm-adjusted across generators per signal/class
Class-conditioning as in analyze_cond.py."""
import sys, os, numpy as np, pandas as pd
from scipy.stats import rankdata, norm
RNG = np.random.RandomState(20261118); NAMES = ["msp", "agree", "other", "ratio"]
def auc(y, s):
    n1 = y.sum(); n0 = len(y) - n1
    if n1 < 20 or n0 < 20: return np.nan
    r = rankdata(s); return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def sc(d): return {"msp": (-d.msp).values, "agree": (-d.agree_pred).values, "other": d.agree_other.values, "ratio": (d.mass_other / d.mass_pred).values}
def holm(p):
    p = np.array(p, float); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for rank, i in enumerate(o): run = max(run, (m - rank) * p[i]); adj[i] = min(1, run)
    return adj
def main(csv, pre):
    d = pd.read_csv(csv); out = []
    for cls, name in [(0, "released_real"), (1, "released_fake")]:
        rel = d[d.pred == cls]
        ref = rel[rel.label == 0]
        sub = pd.concat([rel[(rel.label == 1) & (rel.role == "target")], ref]).reset_index(drop=True)
        y = sub.wrong.values; S = sc(sub)
        # (a) permutation
        for k in NAMES:
            a = auc(y, S[k]); null = np.array([auc(RNG.permutation(y), S[k]) for _ in range(int(os.environ.get("NP",1000)))])
            p = (1 + (np.abs(null - .5) >= abs(a - .5)).sum()) / 1001
            out.append(dict(test="perm_pooled", cls=name, signal=k, auc=a, p=p, n=len(sub)))
        # (b) MSP-matched
        sub["bin"] = pd.qcut(sub.msp.rank(method="first"), 10, labels=False)
        for k in NAMES:
            num = den = 0
            for b, z in sub.groupby("bin"):
                a = auc(z.wrong.values, sc(z)[k])
                if not np.isnan(a): num += a * len(z); den += len(z)
            out.append(dict(test="msp_matched", cls=name, signal=k, auc=num / den if den else np.nan, p=np.nan, n=den))
        # (c) per generator
        rows = []
        for g, f in rel[(rel.label == 1) & (rel.role == "target")].groupby("generator"):
            z = pd.concat([f, ref]).reset_index(drop=True); yy = z.wrong.values; Sz = sc(z)
            if np.isnan(auc(yy, Sz["msp"])): continue
            for k in NAMES:
                a = auc(yy, Sz[k]); bs = []
                for _ in range(int(os.environ.get("NB",300))):
                    i = RNG.randint(0, len(z), len(z))
                    if yy[i].sum() < 5 or (1 - yy[i]).sum() < 5: continue
                    bs.append(auc(yy[i], Sz[k][i]))
                se = np.std(bs); zz = (a - .5) / se if se > 0 else 0; rows.append((g, k, a, 2 * (1 - norm.cdf(abs(zz)))))
        r = pd.DataFrame(rows, columns=["g", "signal", "auc", "p"])
        for k, x in r.groupby("signal"):
            adj = holm(x.p.values)
            out.append(dict(test="gen_holm", cls=name, signal=k, auc=float(np.median(x.auc)), p=float(np.min(adj)), n=len(x),
                            n_sig_up=int(((adj < .05) & (x.auc.values > .5)).sum()), n_sig_down=int(((adj < .05) & (x.auc.values < .5)).sum())))
    r = pd.DataFrame(out); r.to_csv(pre + "_extra.csv", index=False)
    print(r.round(4).to_string())
if __name__ == "__main__": main(sys.argv[1], sys.argv[2])
