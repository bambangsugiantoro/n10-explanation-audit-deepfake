#!/bin/bash
#SBATCH -p l40s
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=14
#SBATCH --mem=64G
#SBATCH -t 12:00:00
#SBATCH -o /virtiofs/work/bambang/cascade/logs/ft_%x_%j.out
# usage: sbatch -J ft_<x> 21_ft_n10.sbatch <timm_name> <model_name>   (6 epoch, DS=face)
export R=/virtiofs/work/bambang/cascade DS=face EPOCHS=6 NW=14
cd $R/scripts
apptainer exec --nv $R/env/pytorch.sif $R/env/venv/bin/python finetune_tier.py "$1" "$2"
