"""N10 analysis of xai_audit CSVs. Usage: python analyze_xai.py <csv> <outprefix>
Scores are oriented so that HIGHER = more suspicious (predicts error):
 msp:-msp | agree:-agree_pred | other:agree_other | ratio:mass_other/mass_pred | margin:-margin
Error = wrong. Bootstrap B=2000 (image level), seed fixed. Paired differences use the same resamples."""
import sys, numpy as np, pandas as pd
from scipy.stats import rankdata
B = int(__import__("os").environ.get("B", 2000)); RNG = np.random.RandomState(20261118)

def auc(y, s):
    n1 = y.sum(); n0 = len(y) - n1
    if n1 < 20 or n0 < 20: return np.nan
    r = rankdata(s); return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)

def boot(y, S, names, ref="msp"):
    """Return dict name->(auc, lo, hi) and dict name->(diff vs ref, lo, hi)."""
    n = len(y); est = {k: auc(y, S[k]) for k in names}
    if np.isnan(est[names[0]]): return None, None
    bs = {k: [] for k in names}
    for _ in range(B):
        i = RNG.randint(0, n, n); yy = y[i]
        if yy.sum() < 5 or (1 - yy).sum() < 5: continue
        for k in names: bs[k].append(auc(yy, S[k][i]))
    bs = {k: np.array(v) for k, v in bs.items()}
    ci = {k: (est[k], *np.nanpercentile(bs[k], [2.5, 97.5])) for k in names}
    df = {k: (est[k] - est[ref], *np.nanpercentile(bs[k] - bs[ref], [2.5, 97.5])) for k in names if k != ref}
    return ci, df

def scores(d):
    return {"msp": (-d.msp).values, "agree": (-d.agree_pred).values, "other": d.agree_other.values,
            "ratio": (d.mass_other / d.mass_pred).values, "margin": (-d.margin).values}
NAMES = ["msp", "agree", "other", "ratio", "margin"]

def main(csv, pre):
    d = pd.read_csv(csv); tgt = d[d.role == "target"].reset_index(drop=True)
    rows = []
    # pooled (target) with strata
    for name, sub in [("target_all", tgt), ("target_fake", tgt[tgt.label == 1]), ("target_real", tgt[tgt.label == 0])]:
        ci, df = boot(sub.wrong.values, scores(sub), NAMES)
        if ci:
            for k in NAMES:
                rows.append(dict(level="pooled", unit=name, signal=k, auc=ci[k][0], lo=ci[k][1], hi=ci[k][2],
                                 diff_vs_msp=df.get(k, (np.nan,))[0], dlo=df.get(k, (0, np.nan, np.nan))[1], dhi=df.get(k, (0, np.nan, np.nan))[2]))
    # per family and per generator (fakes only: error = missed fake)
    for lvl in ["family", "generator"]:
        for g, sub in tgt[tgt.label == 1].groupby(lvl):
            ci, df = boot(sub.wrong.values, scores(sub), NAMES)
            if ci:
                for k in NAMES:
                    rows.append(dict(level=lvl, unit=g, signal=k, auc=ci[k][0], lo=ci[k][1], hi=ci[k][2],
                                     diff_vs_msp=df.get(k, (np.nan,))[0], dlo=df.get(k, (0, np.nan, np.nan))[1], dhi=df.get(k, (0, np.nan, np.nan))[2], n=len(sub)))
    # shift alarm: generator fakes (positive) vs source fakes (negative)
    srcf = d[(d.role == "source") & (d.label == 1)]
    for g, sub in tgt[tgt.label == 1].groupby("generator"):
        z = pd.concat([sub, srcf]).reset_index(drop=True); y = np.r_[np.ones(len(sub)), np.zeros(len(srcf))].astype(int)
        S = scores(z); est = {k: auc(y, S[k]) for k in NAMES}
        for k in NAMES: rows.append(dict(level="shift", unit=g, signal=k, auc=est[k], n=len(sub)))
    r = pd.DataFrame(rows); r.to_csv(pre + "_results.csv", index=False)
    # summaries for H1-H4
    gen = r[r.level == "generator"]
    print("== H1 agreement AUROC per generator: share with CI containing 0.5 =", round(((gen[gen.signal == "agree"].lo <= .5) & (gen[gen.signal == "agree"].hi >= .5)).mean(), 3))
    for k in ["agree", "other", "ratio", "margin"]:
        x = gen[gen.signal == k]; print(f"== H2 {k} - msp: share dCI>0 = {(x.dlo > 0).mean():.3f}; share dCI<0 = {(x.dhi < 0).mean():.3f}; median d = {x.diff_vs_msp.median():.3f}")
    print(r[(r.level == "pooled")].round(3).to_string())
    sh = r[r.level == "shift"].pivot(index="unit", columns="signal", values="auc")
    print("== H4 share of generators where signal beats msp & agree:")
    for k in ["other", "ratio", "margin"]: print(k, round(((sh[k] > sh.msp) & (sh[k] > sh.agree)).mean(), 3))
    print("shift median auc:", sh.median().round(3).to_dict())

if __name__ == "__main__": main(sys.argv[1], sys.argv[2])
