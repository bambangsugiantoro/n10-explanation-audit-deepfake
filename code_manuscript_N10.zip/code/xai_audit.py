"""N10 rebuild: attribution-agreement and counter-class audit for deepfake detectors (no captum needed).

For every sampled image and one detector it saves: p_fake, label, wrong, msp, logit margin, agreement of three
explainers (Grad-CAM, Integrated Gradients, SmoothGrad) for the PREDICTED class and for the UNCHOSEN class,
and attribution-mass ratios. One CSV per (detector, condition).

Usage (inside the cascade container, one GPU):
  python xai_audit.py <timm_name> <model_name> [cond]
  env: DS=face NPER=1500 NREAL=2000 COND=orig SEED=20261118 OUT=$R/xai
Sampling is fixed by SEED and the manifest (no model output is used to choose images).
"""
import os, sys, io, glob, tarfile, time, random
import numpy as np, pandas as pd, torch, torch.nn.functional as F
from PIL import Image
import timm

R = os.environ.get("R", "/virtiofs/work/bambang/cascade")
DS = os.environ.get("DS", "face")
NPER = int(os.environ.get("NPER", 1500)); NREAL = int(os.environ.get("NREAL", 2000))
COND = os.environ.get("COND", "orig"); SEED = int(os.environ.get("SEED", 20261118))
OUT = os.environ.get("OUT", f"{R}/xai"); BS = int(os.environ.get("BS", 8))
IGSTEPS = int(os.environ.get("IGSTEPS", 32)); SGN = int(os.environ.get("SGN", 16)); SGSIGMA = 0.1
TOPK = 20.0
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1); STD = torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1)


# ---------------------------------------------------------------- data
def sample_manifest(man):
    """Fixed, label-blind sample: NPER fakes per generator (target + source roles) and NREAL reals."""
    rng = np.random.RandomState(SEED)
    fake = man[man["label"] == 1]; real = man[man["label"] == 0]
    parts = []
    for g, d in fake.groupby("generator"):
        parts.append(d.sample(min(NPER, len(d)), random_state=rng))
    for role, d in real.groupby("role"):
        parts.append(d.sample(min(NREAL, len(d)), random_state=rng))
    return pd.concat(parts).drop_duplicates("key").reset_index(drop=True)


def read_keys(tar_path, keys):
    out = {}
    with tarfile.open(tar_path) as t:
        for m in t:
            if m.isfile():
                k = m.name.removesuffix(".jpg")
                if k in keys: out[k] = t.extractfile(m).read()
    return out


def to_tensor(b):
    im = Image.open(io.BytesIO(b)).convert("RGB").resize((224, 224), Image.BICUBIC)
    x = torch.from_numpy(np.asarray(im, dtype=np.uint8).copy()).permute(2, 0, 1).float() / 255.
    return (x - MEAN[0]) / STD[0]


def iter_samples(sel):
    """Yield (row, tensor) grouped by shard so each tar is read once."""
    sel = sel.copy(); sel["shard"] = sel["key"].str.rsplit("_", n=1).str[0]
    for shard, d in sel.groupby("shard"):
        p = f"{R}/data/proc/{DS}/{COND}/{shard}.tar"
        if not os.path.exists(p): continue
        got = read_keys(p, set(d["key"]))
        for _, r in d.iterrows():
            if r["key"] in got: yield r, to_tensor(got[r["key"]])


# ---------------------------------------------------------------- explainers
def target_layer(model):
    """Last spatial feature module used by Grad-CAM; returns (module, is_vit)."""
    n = type(model).__name__.lower()
    if "resnet" in n: return model.layer4[-1], False
    if "efficientnet" in n or "mobilenet" in n: return model.blocks[-1], False
    if "convnext" in n: return model.stages[-1], False
    if "vision" in n: return model.blocks[-1], True
    raise ValueError(n)


class CAM:
    def __init__(self, model):
        self.m, self.vit = target_layer(model); self.a = self.g = None
        self.m.register_forward_hook(lambda m, i, o: setattr(self, "a", o))
        self.m.register_full_backward_hook(lambda m, gi, go: setattr(self, "g", go[0]))

    def maps(self, model, x, cls):
        """Grad-CAM for target class cls (tensor (B,)) -> (B,224,224)."""
        x = x.clone().requires_grad_(False)
        logits = model(x); sel = logits.gather(1, cls[:, None]).sum()
        model.zero_grad(set_to_none=True); sel.backward()
        a, g = self.a, self.g
        if self.vit:  # (B,1+N,C) -> (B,C,h,w)
            a, g = a[:, 1:], g[:, 1:]; h = int(a.shape[1] ** 0.5)
            a = a.transpose(1, 2).reshape(a.shape[0], -1, h, h); g = g.transpose(1, 2).reshape(g.shape[0], -1, h, h)
        w = g.mean((2, 3), keepdim=True); cam = F.relu((w * a).sum(1, keepdim=True))
        return F.interpolate(cam, (224, 224), mode="bilinear", align_corners=False)[:, 0].detach()


def integrated_gradients(model, x, cls, steps=IGSTEPS):
    base = torch.zeros_like(x); tot = torch.zeros_like(x)
    for i in range(1, steps + 1):
        z = (base + (i / steps) * (x - base)).requires_grad_(True)
        out = model(z).gather(1, cls[:, None]).sum()
        tot += torch.autograd.grad(out, z)[0]
    return ((x - base) * tot / steps).abs().sum(1).detach()


def smoothgrad(model, x, cls, n=SGN, sigma=SGSIGMA):
    tot = torch.zeros_like(x); sd = sigma * (x.amax((1, 2, 3), keepdim=True) - x.amin((1, 2, 3), keepdim=True))
    for _ in range(n):
        z = (x + torch.randn_like(x) * sd).requires_grad_(True)
        out = model(z).gather(1, cls[:, None]).sum()
        tot += torch.autograd.grad(out, z)[0].abs()
    return (tot / n).sum(1).detach()


def topk_masks(m, k=TOPK):
    B = m.shape[0]; f = m.reshape(B, -1); kk = max(1, int(round(f.shape[1] * k / 100)))
    idx = f.topk(kk, dim=1).indices; mask = torch.zeros_like(f, dtype=torch.bool); mask.scatter_(1, idx, True)
    return mask


def pair_iou(a, b):
    ma, mb = topk_masks(a), topk_masks(b)
    return ((ma & mb).sum(1).float() / (ma | mb).sum(1).clamp(min=1).float())


def agreement(maps):
    gc, ig, sg = maps
    return (pair_iou(gc, ig) + pair_iou(gc, sg) + pair_iou(ig, sg)) / 3, pair_iou(gc, ig), pair_iou(ig, sg)


def explain(model, cam, x, cls):
    gc = cam.maps(model, x, cls); ig = integrated_gradients(model, x, cls); sg = smoothgrad(model, x, cls)
    a, a_gi, a_is = agreement((gc, ig, sg))
    return a, a_gi, a_is, ig.flatten(1).sum(1)


# ---------------------------------------------------------------- main
def main():
    timm_name, name = sys.argv[1], sys.argv[2]
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = timm.create_model(timm_name, pretrained=False, num_classes=2)
    pt = os.environ.get("WEIGHTS", f"{R}/models/{name}.pt")
    if os.path.exists(pt): model.load_state_dict(torch.load(pt, map_location="cpu"))
    else: print("WARNING: no weights at", pt, "(smoke test only)", flush=True)
    model = model.to(dev).eval(); cam = CAM(model)
    man = pd.concat([pd.read_csv(f) for f in glob.glob(f"{R}/data/proc/{DS}/manifest/*.csv")])
    sel = sample_manifest(man); os.makedirs(OUT, exist_ok=True)
    out_csv = f"{OUT}/{name}_{COND}.csv"
    done = set(pd.read_csv(out_csv)["key"]) if os.path.exists(out_csv) else set()
    print(f"{name}: {len(sel)} sampled, {len(done)} done, device {dev}", flush=True)
    rows, buf, t0 = [], [], time.time()

    def flush():
        if not buf: return
        x = torch.stack([b[1] for b in buf]).to(dev); meta = [b[0] for b in buf]
        with torch.no_grad(): lg = model(x); p = torch.softmax(lg, 1)
        pred = p.argmax(1); other = 1 - pred
        a_p, a_gi, a_is, mass_p = explain(model, cam, x, pred)
        a_o, _, _, mass_o = explain(model, cam, x, other)
        for i, r in enumerate(meta):
            pf = float(p[i, 1]); y = int(r["label"])
            rows.append(dict(key=r["key"], generator=r["generator"], family=r["family"], role=r["role"], label=y,
                             p_fake=pf, pred=int(pred[i]), wrong=int((pf >= 0.5) != bool(y)), msp=float(p[i].max()),
                             margin=float(lg[i, pred[i]] - lg[i, other[i]]),
                             agree_pred=float(a_p[i]), agree_gc_ig=float(a_gi[i]), agree_ig_sg=float(a_is[i]),
                             agree_other=float(a_o[i]), mass_pred=float(mass_p[i]), mass_other=float(mass_o[i])))
        buf.clear()
        if len(rows) % (BS * 25) < BS:
            pd.DataFrame(rows).to_csv(out_csv + ".part", index=False)
            print(f"{len(rows)} rows, {time.time()-t0:.0f}s", flush=True)

    todo = sel[~sel["key"].isin(done)]
    for r, x in iter_samples(todo):
        buf.append((r, x))
        if len(buf) == BS: flush()
    flush()
    new = pd.DataFrame(rows)
    if done and os.path.exists(out_csv): new = pd.concat([pd.read_csv(out_csv), new])
    new.to_csv(out_csv, index=False); print("XAI_OK", name, len(new), f"{time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
